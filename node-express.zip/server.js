const http = require('http');
const express = require('express');
const mongoose = require('mongoose');
const app = express();
const todoRoutes = require('./routes/todo');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));


const connectToDatabase = () => {
    console.log("Test");
  //DB_URL = mongodb://localhost:27017/Todo
  const url = "mongodb+srv://apuplay007:oKAz43O0htN90mjR@cluster0.9uluu34.mongodb.net/Todo";
  return mongoose.connect(url, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('Connected to MongoDB!'))
    .catch(error => console.error('Could not connect to MongoDB:', error));
};

connectToDatabase();

app.get('/', (req, res) => {
    res.json({ message: 'Hello World' });
});

app.use('/todo', todoRoutes);

const server = http.createServer(app);
server.listen(3000, () => {
        console.log('listening on *:3000');
    }   
);

