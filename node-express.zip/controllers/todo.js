const fs = require('fs');
const Todo = require('../models/Todo');

exports.getAll = (req, res) => {
    
    try {
        const todos = Todo.find({title: "todo one"});

        res.status(200).json({
            todos
        })
        
    } catch (error) {

       

        res.json({ message: error.message });
    }
}

exports.create = async (req, res) => {
    const { title, description } = req.body;
    try {
        const todo = new Todo({
            title,
            description
        });
        const result = await todo.save();
        res.json({ message: "Create Todo!" , result});

    } catch (error) {

        res.json({ message: error.message });
    }
    

    
}

exports.update = (req, res) => {
    res.json({ message: "Update Todo!" });
}

exports.delete = (req, res) => {
    res.json({ message: "Delete Todo!" });
}

exports.getTodo = (req, res) => {
    const todoId = req.params.id
    res.json({ message: "Get Todo!"+todoId });
}

